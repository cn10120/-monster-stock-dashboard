import { companies } from '../../data/companies';
import CompanyCard from '../components/CompanyCard';
import HelpTip from '../components/HelpTip';

export default function RadarPage() {
  const radar = companies.filter(c => c.radarReason).sort((a, b) => b.score - a.score);
  return (
    <div>
      <h1 className="text-3xl font-bold">Stock Radar <HelpTip term="radarReason" /></h1>
      <p className="mt-3 max-w-3xl text-slate-300">This page shows stocks that filtered in because they match part of the monster-stock profile: high growth, major trend exposure, strong price momentum, AI/data-center relevance, margin expansion, or infrastructure positioning.</p>
      <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {radar.map(company => <CompanyCard key={company.ticker} company={company} />)}
      </div>
    </div>
  );
}
