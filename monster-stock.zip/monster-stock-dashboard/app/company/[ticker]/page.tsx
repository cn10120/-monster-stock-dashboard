import { companies } from '../../../data/companies';
import HelpTip from '../../components/HelpTip';
import Link from 'next/link';

export default function CompanyPage({ params }: { params: { ticker: string } }) {
  const company = companies.find(c => c.ticker.toLowerCase() === params.ticker.toLowerCase());
  if (!company) return <div>Company not found. <Link className="text-sky-300" href="/">Back to dashboard</Link></div>;

  return (
    <div>
      <Link className="text-sm text-sky-300" href="/">← Back</Link>
      <div className="mt-4 rounded-3xl border border-slate-700 bg-slate-900 p-8">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-4xl font-bold">{company.ticker}</h1>
            <p className="mt-1 text-slate-400">{company.name} · {company.category}</p>
          </div>
          <div className="rounded-2xl bg-sky-950 px-5 py-3 text-center">
            <div className="text-xs text-sky-200">Monster Score <HelpTip term="score" /></div>
            <div className="text-3xl font-bold">{company.score}</div>
          </div>
        </div>
        <p className="mt-6 max-w-3xl text-slate-300">{company.thesis}</p>
        {company.radarReason && <p className="mt-4 rounded-xl border border-sky-800 bg-sky-950/40 p-4 text-sky-100">Radar Trigger <HelpTip term="radarReason" />: {company.radarReason}</p>}
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-4">
        <Metric label="Price" value={`$${company.price}`} />
        <Metric label="Day Change" value={`${company.dayChangePct}%`} help="dayChange" />
        <Metric label="YTD" value={`${company.ytdPct}%`} help="ytd" />
        <Metric label="Revenue Growth" value={`${company.revenueGrowth}%`} help="revenueGrowth" />
        <Metric label="Gross Margin" value={`${company.grossMargin}%`} help="grossMargin" />
        <Metric label="Moat" value={`${company.moat}/10`} help="moat" />
        <Metric label="Infrastructure" value={`${company.infrastructure}/10`} help="infrastructure" />
      </div>

      <section className="mt-8 rounded-2xl border border-slate-700 bg-slate-900 p-6">
        <h2 className="text-xl font-bold">Live Data Hook</h2>
        <p className="mt-2 text-slate-300">This starter uses sample data. Connect Finnhub, Polygon, Alpha Vantage, or another provider in the API route to pull real quotes, fundamentals, and news.</p>
      </section>
    </div>
  );
}

function Metric({ label, value, help }: { label: string; value: string; help?: any }) {
  return <div className="rounded-2xl border border-slate-700 bg-slate-900 p-5"><div className="text-sm text-slate-400">{label}{help && <HelpTip term={help} />}</div><div className="mt-2 text-2xl font-bold">{value}</div></div>;
}
