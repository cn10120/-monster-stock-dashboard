import { companies } from '../data/companies';
import CompanyCard from './components/CompanyCard';
import HelpTip from './components/HelpTip';

export default function Dashboard() {
  const watchlist = companies.filter(c => c.watchlist).sort((a, b) => b.score - a.score);
  const topMover = [...companies].sort((a, b) => b.dayChangePct - a.dayChangePct)[0];
  const bestYtd = [...companies].sort((a, b) => b.ytdPct - a.ytdPct)[0];
  const avgScore = Math.round(watchlist.reduce((sum, c) => sum + c.score, 0) / watchlist.length);

  return (
    <div>
      <section className="rounded-3xl border border-slate-700 bg-gradient-to-br from-slate-900 to-slate-950 p-8">
        <div className="max-w-3xl">
          <p className="text-sm uppercase tracking-widest text-sky-300">Personal AI investing command center</p>
          <h1 className="mt-3 text-4xl font-bold">Find companies with monster-stock patterns before they become obvious.</h1>
          <p className="mt-4 text-slate-300">Track your approved watchlist, monitor radar candidates, read daily news notes, and use the help legend to understand every score.</p>
        </div>
      </section>

      <section className="mt-6 grid gap-4 md:grid-cols-3">
        <div className="rounded-2xl border border-slate-700 bg-slate-900 p-5">Average Watchlist Score<HelpTip term="score" /><div className="mt-2 text-3xl font-bold">{avgScore}</div></div>
        <div className="rounded-2xl border border-slate-700 bg-slate-900 p-5">Top Daily Mover<HelpTip term="dayChange" /><div className="mt-2 text-3xl font-bold">{topMover.ticker} {topMover.dayChangePct}%</div></div>
        <div className="rounded-2xl border border-slate-700 bg-slate-900 p-5">Best YTD<HelpTip term="ytd" /><div className="mt-2 text-3xl font-bold">{bestYtd.ticker} {bestYtd.ytdPct}%</div></div>
      </section>

      <h2 className="mt-10 text-2xl font-bold">Main Watchlist</h2>
      <div className="mt-4 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {watchlist.map(company => <CompanyCard key={company.ticker} company={company} />)}
      </div>
    </div>
  );
}
